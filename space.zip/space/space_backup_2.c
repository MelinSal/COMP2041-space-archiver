////////////////////////////////////////////////////////////////////////
// COMP1521 24T1 --- Assignment 2: `space', a simple file archiver
// <https://www.cse.unsw.edu.au/~cs1521/24T1/assignments/ass2/index.html>
//
// Written by Melina Salardini (z5393518) on 4/4/2024.
//
// 2024-03-08   v1.1    Team COMP1521 <cs1521 at cse.unsw.edu.au>

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <fcntl.h>
#include <libgen.h>

#include "space.h"

#define MAX_CONTENT_SIZE 100000

// ADD ANY extra #defines HERE


// ADD YOUR FUNCTION PROTOTYPES (AND STRUCTS IF ANY) HERE

// print the files & directories stored in galaxy_pathname (subset 0)
//
// if long_listing is non-zero then file/directory permissions, formats & sizes
// are also printed (subset 0)

void list_galaxy(char *galaxy_pathname, int long_listing) {
    // open the galaxy for reading
    FILE *galaxy_file = fopen(galaxy_pathname, "rb");
    if (galaxy_file == NULL) {
        perror("Error opening the galaxy file.\n");
        exit(1);
    }

    // storing star data
    uint8_t magic_number;
    uint8_t star_format;
    char permissions[11];
    uint16_t pathname_length = 0;
    char pathname[1000];
    uint64_t content_length = 0;
    uint8_t hash;

    // read the stars of the galaxy till the end of the file
    while (1) {
        pathname_length = 0;
        content_length = 0;
        // read the magic number and make sure the formating is correct
        magic_number = fgetc(galaxy_file);
        if (magic_number != 'c') {
            fprintf(stderr, "Error invalid file format for magic number.\n");
            exit(1);
        }

        // read the star format and make sure the formating is correct
        star_format = fgetc(galaxy_file);
        if (star_format != '6' && star_format != '7' && star_format != '8') {
            fprintf(stderr, "Error invalid file format for star.\n");
            exit(1);
        }

        // read permissions and make sure the formating is correct
        size_t read_count = fread(permissions, sizeof(char), 10, galaxy_file);
        if (read_count != 10) {
            fprintf(stderr, "Error reading permissions.\n");
            exit(1);
        }
        permissions[10] = '\0';

        // reading the pathname_length and make sure the length is correctly formated
        read_count = fread(&pathname_length, sizeof(uint16_t), 1, galaxy_file);
        if (read_count != 1) {
            fprintf(stderr, "Error reading pathname length.\n");
            exit(1);
        };

        // reading the pathname and making sure the length is same as pathname_length
        read_count = fread(pathname, sizeof(char), pathname_length, galaxy_file);
        if (read_count != pathname_length) {
            fprintf(stderr, "Error reading the pathname.\n");
            exit(1);
        }
        pathname[pathname_length] = '\0';

        
        // introduce this because we dont have unit48_t in c
        uint8_t temp_byte;

        // Read the content_length
        for (int i = 0; i < 6; i++) {
            // Read each byte of the 48-bit content length
            temp_byte = 0;
            read_count = fread(&temp_byte, sizeof(uint8_t), 1, galaxy_file);
            if (read_count != 1) {
                fprintf(stderr, "Error reading content length.");
                exit(1);
            }
            // Combine bytes to form the 48-bit content length
            content_length |= (((uint64_t)temp_byte) << (i * 8));
        }

        uint8_t *content = (uint8_t *)malloc(content_length * sizeof(uint8_t));
        if (content == NULL) {
            fprintf(stderr, "Error: Unable to allocate memory for content.\n");
            exit(1);
        }

        // Read the content from the file
        read_count = fread(content, sizeof(uint8_t), content_length, galaxy_file);
        if (read_count != content_length) {
            fprintf(stderr, "Error reading the content.\n");
            free(content);
            exit(1);
        }

        // read the hash
        hash = fgetc(galaxy_file);
        if (hash == 0) {
            fprintf(stderr, "Error reading hash.\n");
            free(content);
            exit(1);
        }

        // Calculate the hash of the star
        uint8_t calculated_hash = 0;
        // calculate hash of magic number
        calculated_hash = galaxy_hash(calculated_hash, magic_number);
        // calculate hash of star format
        calculated_hash = galaxy_hash(calculated_hash, star_format);
        // Hash permissions
        for (int i = 0; i < 10; i++) {
            calculated_hash = galaxy_hash(calculated_hash, permissions[i]);
        }
        // calculate hash of pathname length
        // cause pathname_length is unit16_t and the galaxy_hash function recieves unit8_t
        // it should be calculated twice first for the last byte and then for the first byte
        calculated_hash = galaxy_hash(calculated_hash, (uint8_t)(pathname_length & 0xFF));
        calculated_hash = galaxy_hash(calculated_hash, (uint8_t)(pathname_length >> 8));
        // calculate hash of pathname
        for (int i = 0; i < pathname_length; i++) {
            calculated_hash = galaxy_hash(calculated_hash, pathname[i]);
        }
        // calculate hash of content length
        for (int i = 0; i < 6; i++) {
            calculated_hash = galaxy_hash(calculated_hash, (uint8_t)((content_length >> (i * 8)) & 0xFF));
        }
        // calculate hash of content
        for (uint64_t i = 0; i < content_length; i++) {
            calculated_hash = galaxy_hash(calculated_hash, content[i]);
        }

        //printf("Hash byte: %02x\n", hash);
        //printf("Calculated hash byte: %02x\n", calculated_hash);
        
        // check if the calculated hash is similar to the hash
        if (calculated_hash != hash) {
            fprintf(stderr, "Error the star has been corrupted.\n");
            free(content);
            exit(1);
        }
        


        // base on the command line argument chose what to print in the terminal
        if (long_listing) {
            printf("%s  %c  %5lu  %s\n", permissions, star_format, content_length, pathname);
        } else {
            // Print the basic listing
            printf("%s\n", pathname);
        }

        free(content);

        // exit the while loop is the file ended
        int next_char = fgetc(galaxy_file);
        if (next_char == '\n') {
            break;
        } else if (next_char == EOF) {
            break;
        } else {
            // Put the character back into the stream
            ungetc(next_char, galaxy_file);
        }
    }
    // closing the file
    if (fclose(galaxy_file) != 0) {
        fprintf(stderr, "Error closing the file.\n");
        exit(1);
    }
}


// check the files & directories stored in galaxy_pathname (subset 1)
//
// prints the files & directories stored in galaxy_pathname with a message
// either, indicating the hash byte is correct, or indicating the hash byte
// is incorrect, what the incorrect value is and the correct value would be

void check_galaxy(char *galaxy_pathname) {
    // open the galaxy for reading
    FILE *galaxy_file = fopen(galaxy_pathname, "rb");
    if (galaxy_file == NULL) {
        perror("Error opening the galaxy file.\n");
        exit(1);
    }

    // storing star data
    uint8_t magic_number;
    uint8_t star_format;
    char permissions[11];
    uint16_t pathname_length = 0;
    char pathname[1000];
    uint64_t content_length = 0;
    uint8_t hash;

    // read the stars of the galaxy till the end of the file
    while (1) {
        pathname_length = 0;
        content_length = 0;
        // read the magic number and make sure the formating is correct
        magic_number = fgetc(galaxy_file);
        if (magic_number != 'c') {
            fprintf(stderr, "error: incorrect first star byte: 0x%02x should be 0x63\n", magic_number);
            exit(1);
        }

        // read the star format and make sure the formating is correct
        star_format = fgetc(galaxy_file);
        if (star_format != '6' && star_format != '7' && star_format != '8') {
            fprintf(stderr, "Error invalid file format for star.\n");
            exit(1);
        }

        // read permissions and make sure the formating is correct
        size_t read_count = fread(permissions, sizeof(char), 10, galaxy_file);
        if (read_count != 10) {
            fprintf(stderr, "Error reading permissions.\n");
            exit(1);
        }
        permissions[10] = '\0';

        // reading the pathname_length and make sure the length is correctly formated
        read_count = fread(&pathname_length, sizeof(uint16_t), 1, galaxy_file);
        if (read_count != 1) {
            fprintf(stderr, "Error reading pathname length.\n");
            exit(1);
        };

        // reading the pathname and making sure the length is same as pathname_length
        read_count = fread(pathname, sizeof(char), pathname_length, galaxy_file);
        if (read_count != pathname_length) {
            fprintf(stderr, "Error reading the pathname.\n");
            exit(1);
        }
        pathname[pathname_length] = '\0';

        
        // introduce this because we dont have unit48_t in c
        uint8_t temp_byte;

        // Read the content_length
        for (int i = 0; i < 6; i++) {
            // Read each byte of the 48-bit content length
            temp_byte = 0;
            read_count = fread(&temp_byte, sizeof(uint8_t), 1, galaxy_file);
            if (read_count != 1) {
                fprintf(stderr, "Error reading content length.");
                exit(1);
            }
            // Combine bytes to form the 48-bit content length
            content_length |= ((uint64_t)temp_byte << (i * 8));
        }

        uint8_t *content = (uint8_t *)malloc(content_length * sizeof(uint8_t));
        if (content == NULL) {
            fprintf(stderr, "Error: Unable to allocate memory for content.\n");
            exit(1);
        }

        // Read the content from the file
        read_count = fread(content, sizeof(uint8_t), content_length, galaxy_file);
        if (read_count != content_length) {
            fprintf(stderr, "Error reading the content.\n");
            free(content);
            exit(1);
        }

        // read the hash
        hash = fgetc(galaxy_file);
        if (hash == 0) {
            fprintf(stderr, "Error reading hash.\n");
            free(content);
            exit(1);
        }

        // Calculate the hash of the star
        uint8_t calculated_hash = 0;
        // calculate hash of magic number
        calculated_hash = galaxy_hash(calculated_hash, magic_number);
        // calculate hash of star format
        calculated_hash = galaxy_hash(calculated_hash, star_format);
        // Hash permissions
        for (int i = 0; i < 10; i++) {
            calculated_hash = galaxy_hash(calculated_hash, permissions[i]);
        }
        // calculate hash of pathname length
        // cause pathname_length is unit16_t and the galaxy_hash function recieves unit8_t
        // it should be calculated twice first for the last byte and then for the first byte
        calculated_hash = galaxy_hash(calculated_hash, (uint8_t)(pathname_length & 0xFF));
        calculated_hash = galaxy_hash(calculated_hash, (uint8_t)(pathname_length >> 8));
        // calculate hash of pathname
        for (int i = 0; i < pathname_length; i++) {
            calculated_hash = galaxy_hash(calculated_hash, pathname[i]);
        }
        // calculate hash of content length
        for (int i = 0; i < 6; i++) {
            calculated_hash = galaxy_hash(calculated_hash, (uint8_t)((content_length >> (i * 8)) & 0xFF));
        }
        // calculate hash of content
        for (uint64_t i = 0; i < content_length; i++) {
            calculated_hash = galaxy_hash(calculated_hash, content[i]);
        }

        // check if the calculated hash is the same as the actuall hash
        if (calculated_hash == hash) {
            printf("%s - correct hash\n", pathname);
        } else {
            printf("%s - incorrect hash 0x%02x should be 0x%02x\n", pathname, calculated_hash, hash);
        }

        free(content);

        // exit the while loop is the file ended
        int next_char = fgetc(galaxy_file);
        if (next_char == '\n') {
            break;
        } else if (next_char == EOF) {
            break;
        } else {
            // Put the character back into the stream
            ungetc(next_char, galaxy_file);
        }
    }
    // closing the file
    if (fclose(galaxy_file) != 0) {
        fprintf(stderr, "Error closing the file.\n");
        exit(1);
    }
}


// extract the files/directories stored in galaxy_pathname (subset 1 & 3)

void extract_galaxy(char *galaxy_pathname) {
    // open the galaxy for reading
    FILE *galaxy_file = fopen(galaxy_pathname, "rb");
    if (galaxy_file == NULL) {
        perror("Error opening the galaxy file.\n");
        exit(1);
    }

    // storing star data
    uint8_t magic_number;
    uint8_t star_format;
    char permissions[11];
    uint16_t pathname_length = 0;
    char pathname[1000];
    uint64_t content_length = 0;
    uint8_t hash;

    // read the stars of the galaxy till the end of the file
    while (1) {
        pathname_length = 0;
        content_length = 0;
        // read the magic number and make sure the formating is correct
        magic_number = fgetc(galaxy_file);
        if (magic_number != 'c') {
            fprintf(stderr, "Error invalid file format for magic number.\n");
            exit(1);
        }

        // read the star format and make sure the formating is correct
        star_format = fgetc(galaxy_file);
        if (star_format != '6' && star_format != '7' && star_format != '8') {
            fprintf(stderr, "Error invalid file format for star.\n");
            exit(1);
        }

        // read permissions and make sure the formating is correct
        size_t read_count = fread(permissions, sizeof(char), 10, galaxy_file);
        if (read_count != 10) {
            fprintf(stderr, "Error reading permissions.\n");
            exit(1);
        }
        permissions[10] = '\0';

        // reading the pathname_length and make sure the length is correctly formated
        read_count = fread(&pathname_length, sizeof(uint16_t), 1, galaxy_file);
        if (read_count != 1) {
            fprintf(stderr, "Error reading pathname length.\n");
            exit(1);
        };

        // reading the pathname and making sure the length is same as pathname_length
        read_count = fread(pathname, sizeof(char), pathname_length, galaxy_file);
        if (read_count != pathname_length) {
            fprintf(stderr, "Error reading the pathname.\n");
            exit(1);
        }
        pathname[pathname_length] = '\0';

        
        // introduce this because we dont have unit48_t in c
        uint8_t temp_byte;

        // Read the content_length
        for (int i = 0; i < 6; i++) {
            // Read each byte of the 48-bit content length
            temp_byte = 0;
            read_count = fread(&temp_byte, sizeof(uint8_t), 1, galaxy_file);
            if (read_count != 1) {
                fprintf(stderr, "Error reading content length.");
                exit(1);
            }
            // Combine bytes to form the 48-bit content length
            content_length |= ((uint64_t)temp_byte << (i * 8));
        }

        uint8_t *content = (uint8_t *)malloc(content_length * sizeof(uint8_t));
        if (content == NULL) {
            fprintf(stderr, "Error: Unable to allocate memory for content.\n");
            exit(1);
        }

        // Read the content from the file
        read_count = fread(content, sizeof(uint8_t), content_length, galaxy_file);
        if (read_count != content_length) {
            fprintf(stderr, "Error reading the content.\n");
            free(content);
            exit(1);
        }

        // read the hash
        hash = fgetc(galaxy_file);
        if (hash == 0) {
            fprintf(stderr, "Error reading hash.\n");
            free(content);
            exit(1);
        }

        // Calculate the hash of the star
        uint8_t calculated_hash = 0;
        // calculate hash of magic number
        calculated_hash = galaxy_hash(calculated_hash, magic_number);
        // calculate hash of star format
        calculated_hash = galaxy_hash(calculated_hash, star_format);
        // Hash permissions
        for (int i = 0; i < 10; i++) {
            calculated_hash = galaxy_hash(calculated_hash, permissions[i]);
        }
        // calculate hash of pathname length
        // cause pathname_length is unit16_t and the galaxy_hash function recieves unit8_t
        // it should be calculated twice first for the last byte and then for the first byte
        calculated_hash = galaxy_hash(calculated_hash, (uint8_t)(pathname_length & 0xFF));
        calculated_hash = galaxy_hash(calculated_hash, (uint8_t)(pathname_length >> 8));
        // calculate hash of pathname
        for (int i = 0; i < pathname_length; i++) {
            calculated_hash = galaxy_hash(calculated_hash, pathname[i]);
        }
        // calculate hash of content length
        for (int i = 0; i < 6; i++) {
            calculated_hash = galaxy_hash(calculated_hash, (uint8_t)((content_length >> (i * 8)) & 0xFF));
        }
        // calculate hash of content
        for (uint64_t i = 0; i < content_length; i++) {
            calculated_hash = galaxy_hash(calculated_hash, content[i]);
        }

        // check if the calculated hash is similar to the hash
        if (calculated_hash != hash) {
            fprintf(stderr, "Error the star has been corrupted.\n");
            free(content);
            exit(1);
        }

        // writing the content in a new file
        FILE *extracted_file = fopen(pathname, "wb");
        if (extracted_file == NULL) {
            fprintf(stderr, "Error creating extracted file.\n");
            free(content);
            exit(1);
        }
        fwrite(content, sizeof(uint8_t), content_length, extracted_file);
        fclose(extracted_file);

        // set file permission
        if (chmod(pathname, 0644) == -1) {
            fprintf(stderr, "Error setting file permission.");
            free(content);
            exit(1);
        }

        // print the required format for extracting files
        printf("Extracting: %s\n", pathname);

        free(content);

        // exit the while loop is the file ended
        int next_char = fgetc(galaxy_file);
        if (next_char == '\n') {
            break;
        } else if (next_char == EOF) {
            break;
        } else {
            // Put the character back into the stream
            ungetc(next_char, galaxy_file);
        }
    }
    // closing the file
    if (fclose(galaxy_file) != 0) {
        fprintf(stderr, "Error closing the file.\n");
        exit(1);
    }
}


// create galaxy_pathname containing the files or directories specified in
// pathnames (subset 2 & 3)
//
// if append is zero galaxy_pathname should be over-written if it exists
// if append is non-zero galaxys should be instead appended to galaxy_pathname
//                       if it exists
//
// format specifies the galaxy format to use, it must be one STAR_FMT_6,
// STAR_FMT_7 or STAR_FMT_8
// ADD YOUR EXTRA FUNCTIONS HERE
void extract_base_path(const char *pathname, char *base_path) {
    const char *slash_position = strchr(pathname, '/');
    if (slash_position != NULL) {
        strncpy(base_path, pathname, slash_position - pathname);
        base_path[slash_position - pathname] = '\0';
    } else {
        strcpy(base_path, pathname);
    }
}


void add_file_to_galaxy(FILE *galaxy_file, const char *file_path, const char *relative_path, int format) {
        FILE *add_file = fopen(file_path, "rb");
        if (add_file == NULL) {
            fprintf(stderr, "Error opening %s file.\n", file_path);
            exit(1);
        }

        struct stat s;
        if (stat(file_path, &s) != 0) {
            perror(file_path);
            exit(1);
        }

        uint64_t content_length = s.st_size;
        uint16_t pathname_length = strlen(relative_path);

        // getting the permission and convert it into string
        char permissions[11];
        permissions[0]= (S_ISDIR(s.st_mode)) ? 'd' : '-';
        permissions[1]= (s.st_mode & S_IRUSR) ? 'r' : '-';
        permissions[2]= (s.st_mode & S_IWUSR) ? 'w' : '-';
        permissions[3]= (s.st_mode & S_IXUSR) ? 'x' : '-';
        permissions[4]= (s.st_mode & S_IRGRP) ? 'r' : '-';
        permissions[5]= (s.st_mode & S_IWGRP) ? 'w' : '-';
        permissions[6]= (s.st_mode & S_IXGRP) ? 'x' : '-';
        permissions[7]= (s.st_mode & S_IROTH) ? 'r' : '-';
        permissions[8]= (s.st_mode & S_IWOTH) ? 'w' : '-';
        permissions[9]= (s.st_mode & S_IXOTH) ? 'x' : '-';
        permissions[10]= '\0';

        fputc('c', galaxy_file);

        fputc(format, galaxy_file);

        fwrite(permissions, sizeof(char), 10, galaxy_file);

        fputc(pathname_length & 0xFF, galaxy_file);
        fputc((pathname_length >> 8) & 0xFF, galaxy_file);

        fwrite(relative_path, sizeof(char), pathname_length, galaxy_file);

        for (int j = 0; j < 6; j++) {

            fputc(content_length >> (j * 8) & 0xFF, galaxy_file);
        }

        // write the content
        int c;
        while ((c = fgetc(add_file)) != EOF) {
            fputc(c, galaxy_file);
        }


        // calculate the hash for the current star
        uint8_t calculated_hash = 0;
        calculated_hash = galaxy_hash(calculated_hash, 'c');
        calculated_hash = galaxy_hash(calculated_hash, format);
        for (int j = 0; j < 10; j++) {
            calculated_hash = galaxy_hash(calculated_hash, permissions[j]);
        }
        calculated_hash = galaxy_hash(calculated_hash, (uint8_t)(pathname_length & 0xFF));
        calculated_hash = galaxy_hash(calculated_hash, (uint8_t)(pathname_length >> 8));

        // calculate the hash for relative_path
        for (int i = 0; i < pathname_length; i++) {
            calculated_hash = galaxy_hash(calculated_hash, relative_path[i]);
        }

        // calculate hash for the content length
        for (int j = 0; j < 6; j++) {
            calculated_hash = galaxy_hash(calculated_hash, (uint8_t)((content_length >> (j * 8)) & 0xFF));
        }

        // calculate hash for the content
        rewind(add_file);
        while ((c = fgetc(add_file)) != EOF) {
            calculated_hash = galaxy_hash(calculated_hash, (uint8_t)c);
        }

        fputc(calculated_hash, galaxy_file);

        fclose(add_file);
        //fix : relative_path ?
        printf("Adding: %s\n", relative_path);
}

void add_directory_to_galaxy(FILE *galaxy_file, const char *dir_path, const char *base_path, int format) {
    printf("%s\n", dir_path);
    printf("%s\n", base_path);
    DIR *dirp = opendir(base_path);
    if (dirp == NULL) {
        perror(base_path);
        exit(1);
    }

    struct dirent *de;
    while ((de = readdir(dirp)) != NULL) {
        if (strcmp(de->d_name, ".") == 0 || strcmp(de->d_name, "..") == 0) {
            continue;
        }

        // Check if de->d_name is contained within dir_path
        if (strstr(dir_path, de->d_name) == NULL) {
            continue;
        }

        char updated_base_path[1000];
        snprintf(updated_base_path, sizeof(updated_base_path), "%s/%s", base_path, de->d_name);

        struct stat s;
        if (stat(updated_base_path, &s) != 0) {
            perror(updated_base_path);
            exit(1);
        }

        if (S_ISDIR(s.st_mode)) {
            add_directory_to_galaxy(galaxy_file, dir_path, updated_base_path, format);
        } else {
            add_file_to_galaxy(galaxy_file, dir_path, dir_path, format);
        }
    }

    closedir(dirp);
}


void create_galaxy(char *galaxy_pathname, int append, int format,
                   int n_pathnames, char *pathnames[n_pathnames]) {

    FILE *galaxy_file;

    // determine if we should append or make a galaxy
    if (append) {
        galaxy_file = fopen(galaxy_pathname, "ab");
    } else {
        galaxy_file = fopen(galaxy_pathname, "wb");
    }

    if (galaxy_file == NULL) {
        perror("Error opening the galaxy_file.\n");
        exit(1);
    }

    // loop through each pathname and add to the galaxy_file
    for (int i = 0; i < n_pathnames; i++) {
        char dir_path[1000];
        snprintf(dir_path, sizeof(dir_path), "%s", pathnames[i]);

        char base_path[1000];
        extract_base_path(pathnames[i], base_path);

        struct stat s;
        if (stat(base_path, &s) != 0) {
            perror(base_path);
            exit(1);
        }

        //printf("Debug: Pathname: %s, st_mode: %o\n", base_path, s.st_mode); 
        if (S_ISDIR(s.st_mode)) {
            add_directory_to_galaxy(galaxy_file, dir_path, base_path, format);
        } else {
            add_file_to_galaxy(galaxy_file, pathnames[i], pathnames[i], format);
        }
    }
    if (fclose(galaxy_file) != 0) {
        fprintf(stderr, "Error closing the galaxy file.\n");
        exit(1);
    }
}